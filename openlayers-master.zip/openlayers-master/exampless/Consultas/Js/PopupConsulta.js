function LoteUno ()
{
  MiVentana = window.open("Consultas/Agricola/Lote_Uno.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function LoteDos ()
{
  MiVentana = window.open("Consultas/Agricola/Lote_Dos.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function LoteTres ()
{
  MiVentana = window.open("Consultas/Agricola/Lote_Tres.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function LoteCuatro ()
{
  MiVentana = window.open("Consultas/Agricola/Lote_Cuatro.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}

function LoteCinco ()
{
  MiVentana = window.open("Consultas/Agricola/LoteCinco.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function LoteSeis ()
{
  MiVentana = window.open("Consultas/Agricola/Lote_Seis.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function LoteSiete ()
{
  MiVentana = window.open("Consultas/Agricola/Lote_Siete.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function LoteOcho()
{
  MiVentana = window.open("Consultas/Agricola/Lote_Ocho.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function LoteNueve ()
{
  MiVentana = window.open("Consultas/Agricola/Lote_Nueve.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
 //CULTIVOS
function CultivoCitricos ()
{
  MiVentana = window.open("Consultas/Agricola/Cultivo_Citricos.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function CultivoAnonaceas ()
{
  MiVentana = window.open("Consultas/Agricola/Cultivo_Anonaceas.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function CultivoCacao ()
{
  MiVentana = window.open("Consultas/Agricola/Cultivo_Cacaos.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function CultivoPina ()
{
  MiVentana = window.open("Consultas/Agricola/Cultivo_Citricos.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function CultivoNaranja ()
{
  MiVentana = window.open("Consultas/Agricola/Cultivo_Naranjas.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function CultivoHortalizas ()
{
  MiVentana = window.open("Consultas/Agricola/Cultivo_Hortalizas.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function CultivoUvas ()
{
  MiVentana = window.open("Consultas/Agricola/Cultivo_Uvas.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function CultivoPassifloras ()
{
  MiVentana = window.open("Consultas/Agricola/Cultivo_Passifloras.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function CultivoAromaticas ()
{
  MiVentana = window.open("Consultas/Agricola/Cultivo_Aromaticas.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function CultivoYucas()
{
  MiVentana = window.open("Consultas/Agricola/Cultivo_Yucas.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function CultivoGuayabas()
{
  MiVentana = window.open("Consultas/Agricola/Cultivo_Guayabas.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function CultivoSabilas()
{
  MiVentana = window.open("Consultas/Agricola/Cultivo_Sabilas.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function CultivoPlatanos()
{
  MiVentana = window.open("Consultas/Agricola/Cultivo_Platanos.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
