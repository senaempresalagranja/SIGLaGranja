function Lote(name)
{
  MiVentana = window.open("Consultas/Agricola/Lote.php?name="+name+"", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=556, width=532, height=649");
}

 //CULTIVOS
function Cultivo(name)
{
  MiVentana = window.open("Consultas/Agricola/Cultivo.php?name="+name+"", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=556, width=740, height=649");

}

//CONSTRUCCION
function Construccion(name)
{
  MiVentana = window.open("Consultas/Construccion/construccion.php?name="+name+"", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=556, width=532, height=649");
}
//UNIDAD
function Unidad(name)
{
  MiVentana = window.open("Consultas/Unidad/unidad.php?name="+name+"", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=556, width=532, height=649");
}
function UnidadP(name)
{
  MiVentana = window.open("Consultas/Unidad/unidad_Pecuaria.php?name="+name+"", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=556, width=532, height=649");
}
function MecanizacionA(name)
{
  MiVentana = window.open("Consultas/Mecanizacion/Pista_Tractores.php?name="+name+"", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=556, width=532, height=649");
}
function Ambiental(name)
{
  MiVentana = window.open("Consultas/Unidad/ambiental.php?name="+name+"", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=556, width=532, height=649");
}