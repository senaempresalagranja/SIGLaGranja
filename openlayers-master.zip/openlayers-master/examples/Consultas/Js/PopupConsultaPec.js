function Porcino()
{
  MiVentana = window.open("Consultas/Pecuaria/Unidad_Porcinos.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Planta_Concentrado()
{
  MiVentana = window.open("Consultas/Pecuaria/Unidad_Planta_Concentrados.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Esp_Menores()
{
  MiVentana = window.open("Consultas/Pecuaria/Unidad_Esp_Menores.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}

function Caprinos()
{
  MiVentana = window.open("Consultas/Pecuaria/Unidad_Caprinos.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Ganaderia()
{
  MiVentana = window.open("Consultas/Pecuaria/Unidad_Ganaderia.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Apicultura()
{
  MiVentana = window.open("Consultas/Pecuaria/Unidad_Apicultura.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Piscicultura()
{
  MiVentana = window.open("Consultas/Pecuaria/Unidad_Piscicultura.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Ovinos()
{
  MiVentana = window.open("Consultas/Pecuaria/Unidad_Ovinos.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}

function Labbovinos()
{
  MiVentana = window.open("Consultas/Pecuaria/Unidad_Laboratorio_Reproduccion_Bovina.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}