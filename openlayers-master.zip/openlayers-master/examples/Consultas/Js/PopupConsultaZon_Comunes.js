function Admin ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Admin.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Finca ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Finca.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Amb_Abierto ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Amb_Abierto.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Amb_Nav ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Amb_Nav.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Apoyo_Admin ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Apoyo_Admin.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Banos_Hombres ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Banos_Hombres.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Banos_Instructores ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Banos_Instructores.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Banos_Men ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Banos_Men.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Banos_Woman ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Banos_Woman.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Biblioteca ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Biblioteca.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Bienestar ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Bienestar.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Caf_Instructores ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Caf_Instructores.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Cafeteria ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Cafeteria.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Boleivol ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Boleivol.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Futbol ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Futbol.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Microfutbol ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Microfutbol.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Capilla ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Capilla.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Casino ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Casino.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Enfermeria ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Enfermeria.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Gimnasio ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Gimnasio.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Alojamientos ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Alojamientos.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Alojamiento_Men ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Alojamiento_Men.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}








function Alojamiento_Women ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Alojamiento_Women.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Intendencia ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Intendencia.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Parq_Ins ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Parq_Ins.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Investigacion ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Investigacion.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Parq_Pub ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Parq_Pub.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Plaza_Roja ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Plaza_Roja.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Porteria ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Porteria.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Sala_Instructores ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Sala_Instructores.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Salon_Esmeralda ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Salon_Esmeralda.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Salon_Herramientas ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Salon_Herramientas.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Seg_Lab ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Seg_Lab.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Sombrillas ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Sombrillas.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Tecnoparque ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Tecnoparque.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Agroindustria ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Agroindustria.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Enf ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Enf.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Mecanizacion ()
{
  MiVentana = window.open("Consultas/Zonas_Comunes/Mecanizacion.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}



