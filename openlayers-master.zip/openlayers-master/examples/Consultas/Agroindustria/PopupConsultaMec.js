function Mantenimiento ()
{
  MiVentana = window.open("Consultas/Mecanizacion/Unidad_Mantenimiento.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Invernadero ()
{
  MiVentana = window.open("Consultas/Mecanizacion/Unidad_Invernadero.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Tractores ()
{
  MiVentana = window.open("Consultas/Mecanizacion/Pista_Tractores.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Talleres ()
{
  MiVentana = window.open("Consultas/Mecanizacion/Unidad_Talleres.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}

