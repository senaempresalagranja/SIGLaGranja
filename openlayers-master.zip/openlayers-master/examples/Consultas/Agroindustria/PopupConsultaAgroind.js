function PlantaAntigua()
{
  MiVentana = window.open("Consultas/Agroindustria/Planta_Antigua.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function PlantaNueva()
{
  MiVentana = window.open("Consultas/Agroindustria/Planta_Nueva.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}
function Postcosecha()
{
  MiVentana = window.open("Consultas/Agroindustria/Planta_Antigua.php", "popup", "toolbar=NO, scrollbars=NO, resizable=yes, top=0, left=956, width=310, height=592");
}