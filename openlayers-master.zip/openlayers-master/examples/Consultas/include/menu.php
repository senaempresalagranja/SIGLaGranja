<table border="0">
<tr>
	<td colspan="">
		<button onclick="window.location.href='../Agricola/LoteCinco.php'">General</button>
	</td>


	<td colspan="">
		<button onclick="window.location.href='../Agricola/Inf_Cultivo.php'">Cultivo</button>
	</td>


	<td colspan="">
		<button onclick="window.location.href='../Agricola/Inf_Suelo.php'">Suelo</button>
	</td>

	<td colspan="">
		<button onclick="window.location.href='../Agricola/Inf_Canal.php'">Canal</button>
	</td>


	<td colspan="">
		<button onclick="window.location.href='../Agricola/Inf_Enfermedad.php'">Enfermedades</button>
	</td>
	<td colspan="">
		<button onclick="window.location.href='../Agricola/Inf_Plaga.php'">Plagas</button>
	</td>
</tr>
	
</table>

