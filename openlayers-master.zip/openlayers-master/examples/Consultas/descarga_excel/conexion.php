<?php
/* conexion con postgres */ 
	$con=pg_connect("host=localhost user=postgres password='siglagranja' dbname=siglagranja  port=5432");
?>