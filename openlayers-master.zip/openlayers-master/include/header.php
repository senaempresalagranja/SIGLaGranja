	<head>
<!-- Descripcion para la correcion de tildes y ñ y formate de texto -->
		<meta http-equiv="content-type" content="text/html;charset=utf-8" />
		<meta http-equiv="&aacute; &eacute; &iacute; &oacute; &uacute; &ntilde;" content="text/html; charset=ISO-8859-1" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="keywords" content="Fringila Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web 
		template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<!-- llamado al estilo css de la pagina-->
		<link href="../../css/estilo.css" rel="stylesheet" type="text/css" media="all">
<!-- Titulo de la pagina -->
		<title>Sig La Granja</title>
<!-- Validaciones para numero y texto -->
		<script language="javascript" type="text/javascript">function Solo_Numerico(variable){Numer=parseInt(variable);if (isNaN(Numer)){return "";}return Numer;}function ValNumero(Control){Control.value=Solo_Numerico(Control.value);} </script>
		<script> function validar_texto(e) {tecla = (document.all) ? e.keyCode : e.which; if (tecla==8) return true; patron =/\D/; tecla_final = String.fromCharCode(tecla); return patron.test(tecla_final);} </script>
		

	</head>