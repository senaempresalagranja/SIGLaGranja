<ul class="nav">
	<li></li>
	<li> <a href="../.././visitante/index.php">Inicio</a></li>
	<li><a href="../examples/LaGranja.php">Visor</a></li>
	<li><a href="../.././visitante/acercade.php">Acerca de</a></li>	
</ul>